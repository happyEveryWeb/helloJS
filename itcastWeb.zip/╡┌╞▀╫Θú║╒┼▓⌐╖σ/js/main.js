window.onload = function () {

    /*----------------------------------------------------------------------------------*/
    //杨怡心
//公共类的封装
//获得id：封装id获取对象方法
    function $(id) {
        return document.getElementById(id);
    }
//获得类名：兼容通过类名获取对象
    function cla(name) {
        if (document.getElementsByClassName) {
            return document.getElementsByClassName(name);
        }
        var arr = [];
        var dom = document.getElementsByTagName("*");
        for (var i = 0; i < dom.length; i++) {
            var classarr = dom[i].className.split(" ");
            for (var j = 0; j < classarr.length; j++) {
                if (classarr[j] == name) {
                    arr.push(dom[i]);
                }
            }
        }
        return arr;
    }
    //运动框架
    function animate(obj, json, fn) {
        clearInterval(obj.timer);
        obj.timer = setInterval(function () {
            var flag = true;
            for (var k in json) {
                if (k === "opacity") {
                    var leader = getStyle(obj, k) * 100;
                    var target = json[k] * 100;
                    var step = (target - leader) / 10;
                    step = step > 0 ? Math.ceil(step) : Math.floor(step);
                    leader = leader + step;
                    leader = leader / 100;
                    if ("opacity" in obj.style) {
                        obj.style[k] = leader;
                    } else {
                        obj.style.filter = "alpha(opacity=" + leader + ")";
                    }
                } else if (k === "zIndex") {
                    obj.style.zIndex = json[k];
                } else {
                    var leader = parseInt(getStyle(obj, k)) || 0;
                    var target = json[k];
                    var step = (target - leader) / 10;
                    step = step > 0 ? Math.ceil(step) : Math.floor(step);
                    leader = leader + step;
                    obj.style[k] = leader + "px";
                }
                if (leader !== json[k]) {
                    flag = false;
                }
            }
            if (flag) {
                clearInterval(obj.timer);
                if (fn) {
                    fn();
                }
            }
        }, 15);
    }
    //获取当前对象的属性，配合运动框架一起使用
    function getStyle(obj, attr) {
        if (obj.currentStyle) {
            return obj.currentStyle[attr];
        } else {
            return window.getComputedStyle(obj, null)[attr];
        }
    }


    /*------------------------------------------------------------------------------------*/
//封装缓动方法
    function move(who, starts, ender, flag) {
        var timer = null;
        timer = setInterval(function () {
            if (parseInt((starts - ender) * 100) == 0) {
                starts = ender;
                clearInterval(timer);
            }
            starts = starts + (ender - starts) / 6;
            if (flag == "left") {
                who.style.left = starts + "px";
            }
            if (flag == "top") {
                who.style.top = starts + "px";
            }
            if (flag == "right") {
                who.style.right = starts + "px";
            }
            if (flag == "bottom") {
                who.style.bottom = starts + "px";
            }
        }, 50);
    }

//图随鼠标动
    function banMove() {
        var ban = $("banner");
        var banin = cla("ban-in")[0];
        ban.onmousemove = function (event) {
            var event = event || window.event;
            var x = event.clientX;
            var y = event.clientY;
            var xx = ban.offsetWidth;
            var yy = ban.offsetHeight;
            var top = 90 + (50 - (50 / yy) * y);
            var left = 100 + (45 - (45 / xx) * x);
            banin.style.left = left + "px";
            banin.style.top = top + "px";
        }
    }

//web前端钟表似的转圈
    function picRound() {
        var picr = document.getElementById("picround");
        setInterval(function () {
            var date = new Date();
            var ms = date.getMilliseconds();
            var s = date.getSeconds() + ms / 1000;
            picr.style.webkitTransform = "rotate(" + s * 100 + "deg)";
        }, 100)
    }

//按钮边框动画方法封装
    function btnmove() {
        var num = 86;
        var num1 = -228;
        var num2 = 86;
        var num3 = 228;
        var timer1 = null;

        var sitl = document.getElementById("sit-l");
        var sitr = document.getElementById("sit-r");
        var sitt = document.getElementById("sit-t");
        var sitb = document.getElementById("sit-b");
        var nowsits = document.getElementById("nowsits");

        nowsits.onmouseover = function () {
            clearInterval(timer1);        //每次进来先要终止计时器
            timer1 = setInterval(function () {
                if (num > 0) {
                    num--;
                    sitl.style.top = num + "px";
                }
                if (num1 < 0) {
                    num1 += 10;
                    sitb.style.left = num1 + "px";
                }
                else if (num2 > 0) {
                    num2 -= 5;
                    sitr.style.top = num2 + "px";
                }
                else if (num3 > 0) {
                    num3 -= 5;
                    sitt.style.left = num3 + "px";
                }
            }, 1);
        } //不能同时设置两个计时器来完成，因为会影响
        nowsits.onmouseout = function () {
            clearInterval(timer1);    //每次进来先要终止计时器
            timer1 = setInterval(function () {
                if (num < 86) {
                    num++;
                    sitl.style.top = num + "px";
                }
                if (num3 < 228) {
                    num3 += 5;
                    sitt.style.left = num3 + "px";
                } else if (num2 < 86) {
                    num2 += 5;
                    sitr.style.top = num2 + "px";
                }
                else if (num1 > -228) {
                    num1 -= 10;
                    sitb.style.left = num1 + "px";
                }
            }, 1);
        }
    }

//关闭拉幕
    $("toplm").onclick = function () {
        //cla("lm")[0].style.display = "none";
        jQuery(".lm").slideUp(500);

    }


//调用缓动方法: 文字从两边往中间走，背景图从下往上走效果


//调用图随鼠标动函数
    banMove();

//调用转圈函数
    picRound();

//调用按钮边框的动画方法
    btnmove();

    /*..........................................................................................*/
    //张健
//第一部分 开设校区部分
    function school() {
        var ah = document.getElementsByClassName("hong");
        //获取城市课程显示标签样式
        var apply = document.getElementById("apply");
        var appUls = apply.getElementsByTagName("ul");
        for (var i = 0; i < ah.length; i++) {
            ah[i].onclick = function () {
                //通过循环拿到每一个的值 点击后变成红色  （排它思想）
                for (var i = 0; i < ah.length; i++) {
                    ah[i].style.backgroundColor = "";
                }
                this.style.backgroundColor = "#d72502";
                //循环遍历所有的城市ul标签对象
                for (var j = 0; j < appUls.length; j++) {
                    //现将所有的标签隐藏
                    appUls[j].style.display = "none";
                    //找到当前点击城市对应的className
                    //这里需要后期完善,因为ul里面的classNmae可能有多个
                    if (appUls[j].className == this.name) {
                        appUls[j].style.display = "block";
                    }
                }
                return false;//阻止a标签的跳转行为
            }
        }
    }
    school();
    //点击类名是bai的弹出对话框
    function classWhite() {
        var arr = [];
        var cc = document.getElementById("cc")
        var as = cc.getElementsByTagName("a")
        for (var i = 0; i < as.length; i++) {
            if (as[i].className == "bai") {
                arr.push(as[i])
            }
        }
        for (var i = 0; i < arr.length; i++) {
            arr[i].onclick = function () {
                alert("本校区暂未开设该课程")
                return false;
            }
        }
    }
    classWhite();

//第二部分 选择前端的原因
    //选择前端的原因，鼠标滑过，li的动态效果
    function chooseWeb() {
        var chooseWeb_ul = $("chooseWeb_ul");
        var lis = chooseWeb_ul.children;
        for (var i = 0; i < lis.length; i++) {
            lis[i].onmouseover = function () {
                animate(this, {top: -15});
            };
            lis[i].onmouseout = function () {
                animate(this, {top: 0});
            };
        }
    }

    //刷新页面，li一个一个从隐藏到出现，然后调用 chooseWeb  让鼠标放上去有效果
    function liUp() {
        var chooseWeb_ul = $("chooseWeb_ul");
        var lis = chooseWeb_ul.children;
        for(var i=0;i<lis.length;i++) {
            lis[i].style.top = 353 + "px";
            lis[i].style.opacity = 0;
        }
        animate(lis[0], {"top": 0, "opacity": 1}, function () {
            animate(lis[1], {"top": 0, "opacity": 1}, function () {
                animate(lis[2], {"top": 0, "opacity": 1}, function () {
                    animate(lis[3], {"top": 0, "opacity": 1}, function () {
                        chooseWeb();
                    });
                });
            });
        });
    }
   // liUp();

//按钮动画封装
    function btnjs(btn, timer) {
        var num = -127;
        btn.onmouseover = function () {
            btn.style.color = "#fff";
            clearInterval(timer);
            timer = setInterval(function () {
                num += 10;
                if (num >= 0) {
                    num = 0;
                }
                btn.style.backgroundPositionY = num + "px";
            }, 15);
        };
        btn.onmouseout = function () {
            btn.style.color = "#112131";
            clearInterval(timer);
            timer = setInterval(function () {
                num -= 10;
                if (num <= -127) {
                    num = -127;
                }
                btn.style.backgroundPositionY = num + "px";
            }, 30);
        };

    }

    //调用按钮动画
    var a_btn = cla("a_btn");
    var timer2 = null;
    btnjs(a_btn[0], timer2);
    //....................................................................................

    //刘文静
    /*------------- Mark value ------------------------*/

    //改变折线图中点的大小
    function byID(id) {
        return document.getElementById(id);
    }

    function changeDian(element) {
        element.onmouseover = function () {
            element.style.backgroundColor = "white";
        };
        element.onmouseout = function () {
            element.style.backgroundColor = "rgba(0,0,0,0)";
        };
    }

    function dianElement(element) {
        var dian = byID(element);
        changeDian(dian);
    }

    dianElement("dian0");
    dianElement("dian1");
    dianElement("dian2");
    dianElement("dian3");
    dianElement("dian4");
    dianElement("dian5");
    dianElement("dian6");
    dianElement("dian7");
    dianElement("dian8");
    dianElement("dian9");
    dianElement("dian10");

    //按钮动画的调用
    var btn1 = byID("btn1");
    var btn2 = byID("btn2");
    var btn3 = byID("btn3");
    btnjs(btn1, timer2);
    btnjs(btn2, timer2);
    btnjs(btn3, timer2);

    //饼状图从两边往中间动
    var box_upl = cla("box-upl")[0];
   // move(box_upl,-800,0,"left");

    //饼状图右侧的 条形数据块
    function leftChartDate() {
        var jd = cla("jd");
        for(var i=0;i<jd.length;i++) {
            jd[i].style.opacity = 0;
            jd[i].style.left = -50 + "px";
        }
        animate(jd[0],{"opacity":1,"left":0}, function () {
            animate(jd[1],{"opacity":1,"left":0},function(){
                animate(jd[2],{"opacity":1,"left":0},function() {
                    animate(jd[3],{"opacity":1,"left":0},function(){
                        animate(jd[4],{"opacity":1,"left":0});
                    });
                });
            });
        });
    }
    //setTimeout(leftChartDate,1000);

    //旁边的数字 13740
    function value() {
        var box_upr = cla("box-upr")[0];
        var h2 = box_upr.children[0];
        var spans = h2.children;
        for(var i=0;i<spans.length;i++) {
            spans[i].style.opacity = 0;
        }
        animate(spans[0],{"opacity":1}, function () {
            animate(spans[1],{"opacity":1},function(){
                animate(spans[2],{"opacity":1},function() {
                    animate(spans[3],{"opacity":1},function(){
                        animate(spans[4],{"opacity":1},function() {
                            animate(spans[5],{"opacity":1});
                        });
                    });
                });
            });
        });
    }
   // value();

    //数据下面的 条形数据块
    function rightChartDate() {
        var ul_s = cla("ul-s");
        for(var i=0;i<ul_s.length;i++) {
            ul_s[i].style.opacity = 0;
            ul_s[i].style.left = -50 + "px";
        }
        animate( ul_s[0],{"opacity":1,"left":0},function() {
            animate( ul_s[1],{"opacity":1,"left":0},function(){
                animate( ul_s[2],{"opacity":1,"left":0});
            });
        });
    }
    //setTimeout(rightChartDate,1500);

    //折线图从两边往中间动
    function lineChart() {
        var box_downl = cla("box-downl")[0];
        var box_downr = cla("box-downr")[0];
        move(box_downl,-800,0,"left");
        move(box_downr,-800,0,"right");
    }
   // lineChart();

    /*------------- classmate job ------------------------*/

    //轮播播放就业信息动画
    var scrollDiv = document.getElementById("scrollDiv");
    var table = scrollDiv.children[0];
    var trs = table.getElementsByTagName("tr");
    var right = document.getElementById("right");

    //鼠标经过盒子清理计时器，离开开启计时器
    scrollDiv.onmouseover = function () {
        clearInterval(timer);
    };
    scrollDiv.onmouseout = function () {
        timer = setInterval(right.onclick, 1000);
    };
    var pic = 0;//记录点击次数 点击一次往后移一张图片
    right.onclick = function () {
        //console.log(trs.length);
        if (pic == 26) {
            table.style.top = 0;
            pic = 0;
        }//26次 一轮完了之后返回第一个tr重新开始
        pic++;
        var target = -pic * 48;
        play(table, target);
        //console.log(trs[0]);
        if (pic < 13) {
            trs[0].parentNode.appendChild(trs[pic - 1].cloneNode(true));
        }// 复制前13张追加到最后 将最后一部分填满
        //trs[0].parentNode.removeChild(trs[0]);
    };
    //自动播放的过程
    var timer = setInterval(right.onclick, 1000);
    //自定义一个运动函数
    function play(obj, target) {
        clearInterval(obj.timer);
        obj.timer = setInterval(function () {
            var step = 10;
            var leader = obj.offsetTop;
            step = leader > target ? -step : step;
            if (Math.abs(leader - target) > Math.abs(step)) {
                leader += step;
                obj.style.top = leader + "px";
            } else {
                obj.style.top = target + "px";
                clearInterval(obj.timer);
            }
        }, 15);
    }

    /*..........................................................................................*/

    //张博峰
    //five边框动画方法封装
    function linerMove(bigbox, box1, box2, box3, box4, timer1, it_hot_littlebox, littlebox2) {
        var num = 0;
        var num1 = -600;
        var num2 = -920;
        var num3 = 0;
        bigbox.onmouseover = function () {
            it_hot_littlebox.className = "hidden";
            littlebox2.className = "littlebox2";
            clearInterval(timer1);        //每次进来先要终止计时器
            timer1 = setInterval(function () {
                if (num > -920) {
                    num -= 5;
                    box1.style.top = num + "px";
                }
                if (num1 < 0) {
                    num1 += 3;
                    box2.style.left = num1 + "px";
                }
                if (num2 < 0) {
                    num2 += 5;
                    box3.style.top = num2 + "px";
                }
                if (num3 > -600) {
                    num3 -= 3;
                    box4.style.left = num3 + "px";
                }

            },1);
        } //不能同时设置两个计时器来完成，因为会影响
        bigbox.onmouseout = function () {
            it_hot_littlebox.className = "it_hot_littlebox";
            littlebox2.className = "hidden";
            clearInterval(timer1);    //每次进来先要终止计时器
            timer1 = setInterval(function () {
                if (num3 < 0) {
                    num3 += 3;
                    box4.style.left = num3 + "px";
                }
                if (num2 > -920) {
                    num2 -= 5;
                    box3.style.top = num2 + "px";
                }
                if (num1 > -600) {
                    num1 -= 3;
                    box2.style.left = num1 + "px";
                }
                if (num < 0) {
                    num += 5;
                    box1.style.top = num + "px";
                }
            }, 1);
        }
    }

    //five边框动画方法调用
    var box1 = cla("box1");
    var box2 = cla("box2");
    var box3 = cla("box3");
    var box4 = cla("box4");
    var bigbox = cla("bigbox");
    var timer0 = null;
    var it_hot_littlebox = cla("it_hot_littlebox");
    var littlebox2 = cla("littlebox2");
    linerMove(bigbox[0], box1[0], box2[0], box3[0], box4[0], timer0, it_hot_littlebox[0], littlebox2[0]);
    var timer1 = null;
    linerMove(bigbox[1], box1[1], box2[1], box3[1], box4[1], timer1, it_hot_littlebox[1], littlebox2[1]);
    var timer2 = null;
    linerMove(bigbox[2], box1[2], box2[2], box3[2], box4[2], timer2, it_hot_littlebox[2], littlebox2[2]);

    //five 按钮动画调用
    btnjs(a_btn[1], timer0);
    btnjs(a_btn[2], timer0);

    //手风琴效果
    var accordion = cla("accordion")[0];
    var accordion_ul = accordion.children[0];
    var accordion_lis = accordion_ul.children;
    for (var i = 0; i < accordion_lis.length; i++) {
        accordion_lis[i].index = i;
        accordion_lis[i].onmouseover = function () {
            for (var i = 0; i < accordion_lis.length; i++) {
                if (i <= this.index) {
                    var a = i * 30;
                    animate(accordion_lis[i], {"left": a});
                } else if (i > this.index) {
                    var b = 960 - (accordion_lis.length - i) * 30;
                    animate(accordion_lis[i], {"left": b});
                }
            }
        }
        accordion_lis[i].onmouseout = function () {
            for (var i = 0; i < accordion_lis.length; i++) {
                var c = i * 120;
                animate(accordion_lis[i], {"left": c});
            }
        }
    }

    /*..........................................................................................*/

    /*李亚超*/
    /*------ class -----------*/
    //调用按钮动画
    var button1 = $("button1");
    var button2 = $("button2");
    btnjs(button1, timer0);
    btnjs(button2, timer0);
    btnjs(a_btn[3], timer0);
    btnjs(a_btn[4], timer0);

    function wellClass(){
        var ul1 = document.getElementById("boxin_ul1");
        var ul2 = document.getElementById("boxin_ul2");
        var midquary = document.getElementById("midquary");
        var lis1 = ul1.getElementsByTagName("li");
        var lis2 = ul2.getElementsByTagName("li");
        var divs = midquary.getElementsByTagName("div");
        //左侧
        for(var i=0;i<lis1.length;i++){
            lis1[i].index = i;
            lis1[i].onmouseover= function () {
              for(var i=0;i<divs.length;i++){
                  divs[i].style.display = "none";
              }
                divs[this.index].style.display = "block";
            };
        }
        //右侧
        for(var i=0;i<lis2.length;i++){
            lis2[i].index = i;
            lis2[i].onmouseover= function () {
                for(var i=0;i<divs.length;i++){
                    divs[i].style.display = "none";
                }
                divs[this.index+3].style.display = "block";
            };
        }
    }
    wellClass();

    /*------ students achievement -----------*/
    function liRotate(obj,json,ro,fn) {
        for( var k in json) {
            if (k == "opacity") {
                obj.style[k] =0;
            } if(k == "transform") {
                obj.style[k] ="rotate("+ro+"deg)";
            }else {
                obj.style[k] =0+ "px";
            }
        }
        clearInterval(obj.timer);
        obj.timer = setInterval(function () {
            for( var k in json) {
                var flag = true;
                if (k == "opacity" || k == "borderRadius") {
                    var leader = getStyle(obj, k) * 100;
                    var target = json[k] * 100;
                    var step = (target - leader) / 10;
                    step = step > 0 ? Math.ceil(step) : Math.floor(step);
                    leader += step;
                    obj.style[k] = leader / 100;
                } if(k == "transform") {
                    var target = json[k];
                    var step = (target - ro) / 10;
                    step = step > 0 ? Math.ceil(step) : Math.floor(step);
                    ro += step;
                    obj.style[k] ="rotate("+ro+"deg)";
                }else {
                    var leader = parseInt(getStyle(obj, k)) || 0;
                    var target = json[k];
                    var step = (target - leader) / 10;
                    step = step > 0 ? Math.ceil(step) : Math.floor(step);
                    leader += step;
                    obj.style[k] = leader + step + "px";
                }if (leader != target||ro!=target) {
                    flag = false;
                }
            }
            if (flag) {
                clearInterval(obj.timer);
                if (fn) {
                    fn();
                }
            }
        }, 30);
    }
    function production() {
        var show = $("show");
        //console.log(show);
        var btn1 = $("buttonin1");
        //console.log(btn1);
        var btn2 = $("buttonin2");
        var btn3 = $("buttonin3");
        var show1 = $("content2_show1");
        //console.log(show1);
        var show2 = $("content2_show2");
        var show3 = $("content2_show3");
        btn1.onclick = function () {
            btn2.className="";
            btn3.className="";
            this.className="current";
            show1.style.display = "block";
            var lis=show1.getElementsByTagName("li");
            for(var i=0;i<lis.length;i++){
                liRotate(lis[i],{"opacity":1,"transform":0,"width":300,"height":226},25);
            }
            show2.style.display = "none";
            show3.style.display = "none";
        }
        btn2.onclick = function () {
            btn1.className="";
            btn3.className="";
            this.className="current";
            show2.style.display = "block";
            var lis=show2.getElementsByTagName("li");
            for(var i=0;i<lis.length;i++){
                liRotate(lis[i],{"opacity":1,"transform":0,"width":300,"height":226},25);
            }
            show1.style.display = "none";
            show3.style.display = "none";
        }
        btn3.onclick = function () {
            btn2.className="";
            btn1.className="";
            this.className="current";
            show3.style.display = "block";
            var lis=show3.getElementsByTagName("li");
            for(var i=0;i<lis.length;i++){
                liRotate(lis[i],{"opacity":1,"transform":0,"width":300,"height":226},25);
            }
            show1.style.display = "none";
            show2.style.display = "none";
        }
    }
    production();

    /*------ old hand -----------*/
    var oldHand = $("oldHand");
    var lis = oldHand.getElementsByTagName("li");
    var infos=cla("info");
    for (var i = 0; i < lis.length; i++) {
        J_move(lis[i],infos[i]);
    }
    function J_move(obj,box) {
        jQuery(obj).on("mouseenter mouseleave", function (e) {
            var w = jQuery(this).width(); // 得到盒子宽度
            var h = jQuery(this).height();// 得到盒子高度
            var x = (e.pageX - this.offsetLeft - (w / 2)) * (w > h ? (h / w) : 1);
            // 获取x值
            var y = (e.pageY - this.offsetTop - (h / 2)) * (h > w ? (w / h) : 1);
            // 获取y值
            var direction = Math.round((((Math.atan2(y, x) * (180 / Math.PI)) + 180) / 90) + 3) % 4; //direction的值为“0,1,2,3”分别对应着“上，右，下，左”
            // 将点的坐标对应的弧度值换算成角度度数值  0123  上右下左
            if (e.type == 'mouseenter') {
                if (direction == 0) {
                    jQuery(box)[0].style.left = 0;
                    jQuery(box)[0].style.top = -178 + "px";
                    jQuery(box).animate({"top": "0"}, 200);
                } else if (direction == 1) {
                    jQuery(box)[0].style.left = 178 + "px";
                    jQuery(box)[0].style.top = 0 + "px";
                    jQuery(box).animate({"left": "0"}, 200);
                } else if (direction == 2) {
                    jQuery(box)[0].style.left = 0;
                    jQuery(box)[0].style.top = 178 + "px";
                    jQuery(box).animate({"top": "0"}, 200);
                } else if (direction == 3) {
                    jQuery(box)[0].style.left = -178 + "px";
                    jQuery(box)[0].style.top = 0 + "px";
                    jQuery(box).animate({"left": "0"}, 200);
                }
            } else {
                if (direction == 0) {
                    jQuery(box).animate({"top": "-178"}, 200);
                } else if (direction == 1) {
                    jQuery(box).animate({"left": "178"}, 200);
                } else if (direction == 2) {
                    jQuery(box).animate({"top": "178"}, 200);
                } else if (direction == 3) {
                    jQuery(box).animate({"left": "-178"}, 200);
                }
            }
        });
    }

    /*..........................................................................................*/
    //田苗

        /*二维码部分*/
        var ewmbox = document.getElementsByClassName("ewmbox");
        var ewmboxqq = document.getElementsByClassName("ewmboxqq");
        var ewm = document.getElementsByClassName("ewm");

        for(var i=0; i<ewmbox.length; i++){
            ewmbox[i].index = i;
            ewmbox[i].onmouseover = function(){
                ewmboxqq[this.index].children[0].src = "../images/"+this.index +".png";
                ewmboxqq[this.index].style.marginTop = 0;
                ewmboxqq[this.index].style.marginLeft = 0;
                ewm[this.index].style.display = "block";
            };
            ewmbox[i].onmouseout = function(){
                ewmboxqq[this.index].children[0].src = "../images/"+this.index+".jpg";
                ewmboxqq[this.index].style.marginTop = "0px";
                ewmboxqq[this.index].style.marginLeft = "0px";
                ewm[this.index].style.display = "none";
            };
        }

        /*地区部分*/
        var map = document.getElementById("map");
        var ul = map.children[0];
        var lis = ul.children;
        for(var i=0; i<lis.length; i++){
            lis[i].onmouseover = function(){
                this.children[2].style.display = "block";
            };
            lis[i].onmouseout = function(){
                this.children[2].style.display = "none";
            };
            setInterval(function(){
                for(var i=0; i<lis.length; i++){
                    animate(lis[i].children[0], {"top":5}, function(){
                        for(var i=0; i<lis.length; i++){
                            animate(lis[i].children[0], {"top":0});
                        }
                    })
                }
            }, 800);
        }

        //表单验证
        var userName = document.getElementById("userName");
        var phoneNum = document.getElementById("phoneNum");
        var QQnum = document.getElementById("QQNum");
        var btn = document.getElementById("btn");
        var sel = document.getElementById("selId");
        var op = sel.children[0];
        var options = sel.getElementsByTagName("option");

        var flag1 = false;
        var flag2 = false;
        var flag3 = false;
        var flag4 = false;

        var regQQ = /^[1-9]\d{4,10}$/;
        var regTel = /^1[34578]\d{9}$/;
        var regName = /^[\u4e00-\u9fa5]{2,6}$/;



        //用户名验证
        userName.onfocus = function(){
            if(this.value === "我们期待更了解您"){
                this.value = "";
            }
            this.nextElementSibling.innerText = "";
            this.style.color = "black";
        }
        userName.onblur = function(){
            flag1 = false;
            if(this.value.trim() === ""){
                this.value = "我们期待更了解您";
                this.style.color = "";
            }
            if(regName.test(this.value)){
                flag1 = true;
            }else if(this.value === "我们期待更了解您"){
                this.nextElementSibling.innerText = "";
            } else{
                this.nextElementSibling.innerText = "错误";
                this.nextElementSibling.className = "red";
            }
        }

        //电话号码验证
        phoneNum.onfocus = function(){
            if(this.value === "我们和您一样讨厌骚扰电话"){
                this.value = "";
            }
            this.nextElementSibling.innerText = "";
            this.style.color = "black";
        }
        phoneNum.onblur = function(){
            flag2 = false;
            if(this.value.trim() === ""){
                this.value = "我们和您一样讨厌骚扰电话";
                this.style.color = "";
            }
            if(regTel.test(this.value)){
                flag2 = true;
            }else if(this.value === "我们和您一样讨厌骚扰电话"){
                this.nextElementSibling.innerText = "";
            } else{
                this.nextElementSibling.innerText = "错误";
                this.nextElementSibling.className = "red";
            }
        }

        //QQ号码验证
        QQnum.onfocus = function(){
            if(this.value === "我们将尽快与您联系"){
                this.value = "";
            }
            this.nextElementSibling.innerText = "";
            this.style.color = "black";
        }
        QQnum.onblur = function(){
            flag3 = false;
            if(this.value.trim() === ""){
                this.value = "我们将尽快与您联系";
                this.style.color = "";
            }
            if(regQQ.test(this.value)){
                flag3 = true;
            }else if(this.value === "我们将尽快与您联系"){
                this.nextElementSibling.innerText = "";
            } else{
                this.nextElementSibling.innerText = "错误";
                this.nextElementSibling.className = "red";
            }
        }


        //验证下拉菜单
        sel.onchange = function(){
            for(var i = 0; i < options.length; i++){
                if(options[i].selected === true){
                    if(options[i].innerText !== "请选择上课地址"){
                        flag4 = true;
                    }else{
                        flag4 = false;
                    }
                }
            }
        }

        btn.onclick = function(){
            if(flag1 && flag2 && flag3 && flag4){
                alert("恭喜你，报名成功！");
            }else{
                alert("个人信息有误，报名失败！");
            }
        }

    //map 运动动画
    function mapMove(){
        var txt = cla("txt")[1];
        var map = $("map");
    move(txt,-130,0,"left");
    move(map,-130,0,"right");
    }
    //mapMove();
    /*----------------------------------------------------------------------------------------*/

// 动画的遮罩
    function zhezhao(){
        var aa=$("show").getElementsByTagName("img");
        var bg=$("scrMask12");  //遮罩
        var bgin=$("showMask12");  //图片
        var imgs=bgin.getElementsByTagName("img");  //大图片
        for(var i=0;i<aa.length;i++){
            aa[i].index=i;
            var jso=[
                {"pw0":422,"ph0":668},  // 图片 宽 422  高 668
                {"pw1":404,"ph1":572},
                {"pw2":404,"ph2":620},
                {"pw3":404,"ph3":624},
                {"pw4":440,"ph4":630},
                {"pw5":458,"ph5":620},
                {"pw6":404,"ph6":648},
                {"pw7":440,"ph7":626},
                {"pw8":404,"ph8":624},
                {"pw9":422,"ph9":622},
                {"pw10":440,"ph10":654},
                {"pw11":440,"ph11":666},
                {"pw12":900,"ph12":670},
                {"pw13":900,"ph13":670},
                {"pw14":900,"ph14":670},
                {"pw15":900,"ph15":670},
                {"pw16":900,"ph16":670},
                {"pw17":900,"ph17":670}];
            aa[i].onclick=function(event){
                bg.style.display="block";
                bg.style.height = 700 + "px";
                bgin.style.display="block";
                //阻止冒泡
                var event=event||window.event;
                if(event&&event.stopPropagation){
                    event.stopPropagation();
                }else{
                    event.cancelBubble=true;
                }
                //排它
                for(var j=0;j<imgs.length;j++){
                    imgs[j].style.display="none";
                }
                imgs[this.index].style.display="inline";
                var ww="pw"+this.index;
                var hh="ph"+this.index;
                liRotate(imgs[this.index],{"width":jso[this.index][ww],"height":jso[this.index][hh]},0);
                return false;
            }
        }

        bgin.onclick=function(){
            var starts=700;
            var ender=0;
                bgin.style.display="none";
            for(var j=0;j<imgs.length;j++){
                imgs[j].style.display="none";
            }
                var timer = null;
                timer = setInterval(function () {
                    if (parseInt((starts - ender) * 1) == 0) {
                        starts = ender;
                        clearInterval(timer);
                        flag=false;
                    }
                    starts = starts + (ender - starts) / 6;
                    bg.style.height = starts + "px";
                }, 10);
            }
        }
    zhezhao();

    /*-------------------------------------------------------------------------------------*/

    //左右两侧固定侧边栏
   function rightLink() {
       var right_ul = document.getElementById("advs");
        var list = right_ul.children;
       var qw =document.getElementById("qw");
       for(var i =0;i<list.length;i++){
           if(i!=0&&i!=6) {
               list[i].index = i;
               list[i].onmouseover = function () {
                   if(this.index == 4){
                       qw.style.display ="block"
                   }
                   for (var i = 0; i < list.length; i++) {
                       if(i!=0&&i!=6) {
                           list[i].style.backgroundColor = "";
                       }
                   };
                   this.style.backgroundColor = "red";
               }
               list[i].onmouseout = function () {
                   for(var i=0;i<list.length;i++){
                       list[i].style.backgroundColor = "";
                       if(i ==4){
                           qw.style.display ="none"
                       };
                   };

               };
           };
       };
  }
    rightLink();

    //左侧广告栏
    var ra = document.getElementById("rads");
    var ras  =document.getElementById("rad-ins");
    var USB  =ra.children[0];
    ra.onmouseover = function () {
        ras.style.display = "block";
    }
    ra.onmouseout = function () {
        ras.style.display = "none";
    }
    var flag1 = true;
    var flag2 = true;
    var flag3 = true;
    var flag4 = true;
    window.onscroll = function() {
        var scrTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
        if(parseInt(scrTop)>30) {
            if(flag1) {
                var backg = $("backg");
                var pict = cla("pic-t")[0];
                var picb = cla("pic-b")[0];
                flag1 = false;
                move(backg, 732, -2, "top");
                move(pict, -832, 0, "left");
                move(picb, -682, 138, "right");
            }
        }
        if(parseInt(scrTop)>1000) {
            if(flag2) {
                flag2 = false;
                liUp();
            }
        }
        if(parseInt(scrTop)>2000) {
            if(flag3) {
                flag3 = false;
                move(box_upl,-800,0,"left");
                setTimeout(leftChartDate,1000);
                value();
                setTimeout(rightChartDate,1500);
                setTimeout(lineChart,1000);
            }
        }
        if(parseInt(scrTop)>10000) {
            if(flag4) {
                flag4 = false;
                mapMove();
            }
        }
        if (parseInt(scrTop) < 800) {
            USB.style.display = "none";
        } else {
            USB.style.display = "block";
        }
    };
}






